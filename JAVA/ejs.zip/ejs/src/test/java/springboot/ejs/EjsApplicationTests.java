package springboot.ejs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjsApplicationTests {

	@Test
	void contextLoads() {
	}

}
