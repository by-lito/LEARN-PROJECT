package springboot.ejs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjsApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjsApplication.class, args);
	}

}
